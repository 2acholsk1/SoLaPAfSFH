# QGIS-segmentacja 2 > 2025-01-15 1:45pm
https://universe.roboflow.com/qgissegmentacja/qgis-segmentacja-2

Provided by a Roboflow user
License: CC BY 4.0


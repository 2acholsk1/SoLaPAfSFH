# SoLaPAfSFH > 2024-12-14 10:29pm
https://universe.roboflow.com/zacholworkspace/solapafsfh

Provided by a Roboflow user
License: CC BY 4.0

